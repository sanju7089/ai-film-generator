# Smart Work Network — local services marketplace MVP

Hindi-first marketplace starter: people can post household/service work and providers can create skill profiles, search open work, send requests, save profiles, respond to requests, and submit reviews/reports.

## Stack
- Node.js + Express API
- MongoDB + Mongoose
- Password hashing with bcrypt
- JWT in HttpOnly cookie
- Helmet, rate limiting, and basic CORS configuration
- Responsive HTML/CSS/vanilla JavaScript pages

## Run locally
1. Install Node.js LTS and MongoDB Community (or use a MongoDB Atlas connection string).
2. In this folder run: `npm install`
3. Copy `.env.example` to `.env`, and set a strong unique `JWT_SECRET` and your `MONGODB_URI`.
4. Run: `npm start`
5. Open: `http://localhost:3000`

## Pages
- Home, About, How it works, Contact, FAQ
- Services/jobs, Post work, Provider directory, Categories, Popular, Search, Details
- Login, Signup, Dashboard, Profile, Activity/Requests, Saved
- Report, Reviews, Safety, Terms, Privacy, Refund/cancellation
- Help, Blog, Plans, Notifications, Sitemap, 404

## API overview
- `POST /api/auth/register`, `/api/auth/login`, `/api/auth/logout`, `GET /api/auth/me`
- `PATCH /api/profile`
- `GET /api/providers`, `GET /api/providers/:id`
- `GET /api/jobs`, `POST /api/jobs`, `GET /api/jobs/:id`, `POST /api/jobs/:id/request`
- `GET /api/requests/mine`, `PATCH /api/requests/:id`
- `POST /api/favorites/:id`, `GET /api/favorites`
- `POST /api/reviews`, `POST /api/reports`, `GET /api/stats`, `GET /api/health`

## Important launch limitations
This is a working MVP scaffold, not yet a fully audited production marketplace. Worker and customer identity are **not verified**. It does not include SMS/email OTP, document/KYC checks, messaging/chat, payment escrow, admin moderation panel, email delivery, password reset, automated dispute handling, or guaranteed refunds. The verification label is not actively awarded by this code. Before public launch, add OTP/KYC and moderation, configure production CORS/origin, deploy over HTTPS, add backups and monitoring, and get the policies reviewed.
