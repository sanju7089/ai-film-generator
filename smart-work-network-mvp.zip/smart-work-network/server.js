import 'dotenv/config';
import express from 'express';
import mongoose from 'mongoose';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

const app = express();
const PORT = process.env.PORT || 3000;
const MONGO = process.env.MONGODB_URI;
const JWT_SECRET = process.env.JWT_SECRET;
if (!MONGO || !JWT_SECRET) { console.error('Set MONGODB_URI and JWT_SECRET in .env'); process.exit(1); }
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.FRONTEND_URL || true, credentials: true }));
app.use(express.json({ limit: '1mb' }));
app.use(cookieParser());
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, limit: 60, standardHeaders: true, legacyHeaders: false }));
app.use(express.static('public'));

const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 80 }, email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  phone: { type: String, trim: true, maxlength: 20 }, passwordHash: { type: String, required: true }, role: { type: String, enum: ['customer','provider','both'], default: 'both' },
  city: { type: String, trim: true, maxlength: 80 }, bio: { type: String, maxlength: 800 }, skills: [String], hourlyRate: Number, availability: String,
  favorites: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }], isVerified: { type: Boolean, default: false }
}, { timestamps: true });
const User = mongoose.model('User', userSchema);
const jobSchema = new mongoose.Schema({ title: { type: String, required: true, maxlength: 120 }, description: { type: String, required: true, maxlength: 3000 }, category: { type: String, required: true }, location: { type: String, required: true }, budget: Number, schedule: String, owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }, status: { type: String, enum: ['open','assigned','completed','cancelled'], default: 'open' } }, { timestamps: true });
const Job = mongoose.model('Job', jobSchema);
const requestSchema = new mongoose.Schema({ job: { type: mongoose.Schema.Types.ObjectId, ref: 'Job', required: true }, provider: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }, customer: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }, note: { type: String, maxlength: 1000 }, status: { type: String, enum: ['pending','accepted','declined','cancelled','completed'], default: 'pending' } }, { timestamps: true });
requestSchema.index({ job: 1, provider: 1 }, { unique: true });
const WorkRequest = mongoose.model('WorkRequest', requestSchema);
const reviewSchema = new mongoose.Schema({ target: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }, author: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }, job: { type: mongoose.Schema.Types.ObjectId, ref: 'Job' }, rating: { type: Number, min: 1, max: 5, required: true }, text: { type: String, maxlength: 1000 } }, { timestamps: true });
const Review = mongoose.model('Review', reviewSchema);
const reportSchema = new mongoose.Schema({ reporter: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, subjectType: String, subjectId: String, details: { type: String, required: true, maxlength: 3000 }, status: { type: String, default: 'new' } }, { timestamps: true });
const Report = mongoose.model('Report', reportSchema);

const safeUser = (u) => ({ id: u._id, name: u.name, email: u.email, phone: u.phone, role: u.role, city: u.city, bio: u.bio, skills: u.skills, hourlyRate: u.hourlyRate, availability: u.availability, isVerified: u.isVerified, createdAt: u.createdAt });
function auth(req, res, next) { const token = req.cookies.swntoken; if (!token) return res.status(401).json({ error: 'Login required' }); try { req.user = jwt.verify(token, JWT_SECRET); next(); } catch { res.clearCookie('swntoken'); return res.status(401).json({ error: 'Session expired, please login again' }); } }
function tokenFor(u) { return jwt.sign({ id: String(u._id), role: u.role }, JWT_SECRET, { expiresIn: '7d' }); }
function setCookie(res, token) { res.cookie('swntoken', token, { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'lax', maxAge: 7 * 24 * 60 * 60 * 1000 }); }
function errorHandler(err, req, res, next) { console.error(err); res.status(err.status || 500).json({ error: err.message || 'Server error' }); }

app.get('/api/health', (req,res)=>res.json({ status: 'ok', service: 'Smart Work Network' }));
app.post('/api/auth/register', async (req,res,next)=>{ try { const {name,email,password,role='both',phone,city}=req.body; if(!name||!email||!password) return res.status(400).json({error:'Name, email and password are required'}); if(password.length<8) return res.status(400).json({error:'Password must be at least 8 characters'}); if(!['customer','provider','both'].includes(role)) return res.status(400).json({error:'Invalid role'}); const hash=await bcrypt.hash(password,12); const u=await User.create({name,email,phone,city,role,passwordHash:hash}); setCookie(res,tokenFor(u)); res.status(201).json({user:safeUser(u)}); } catch(e){ if(e.code===11000) return res.status(409).json({error:'Email already registered'}); next(e); }});
app.post('/api/auth/login', async(req,res,next)=>{ try{ const {email,password}=req.body; const u=await User.findOne({email:String(email||'').toLowerCase()}); if(!u||!await bcrypt.compare(password||'',u.passwordHash)) return res.status(401).json({error:'Email or password is incorrect'}); setCookie(res,tokenFor(u)); res.json({user:safeUser(u)}); }catch(e){next(e);} });
app.post('/api/auth/logout',(req,res)=>{res.clearCookie('swntoken');res.json({message:'Logged out'});});
app.get('/api/auth/me',auth,async(req,res,next)=>{try{const u=await User.findById(req.user.id);if(!u)return res.status(401).json({error:'Account not found'});res.json({user:safeUser(u)});}catch(e){next(e);}});
app.patch('/api/profile',auth,async(req,res,next)=>{try{const allowed=['name','phone','city','bio','skills','hourlyRate','availability','role'];const updates={};for(const k of allowed)if(req.body[k]!==undefined)updates[k]=req.body[k];if(updates.role&&!['customer','provider','both'].includes(updates.role))return res.status(400).json({error:'Invalid role'});const u=await User.findByIdAndUpdate(req.user.id,updates,{new:true,runValidators:true});res.json({user:safeUser(u)});}catch(e){next(e);}});
app.get('/api/providers',async(req,res,next)=>{try{const filter={role:{$in:['provider','both']}};if(req.query.city)filter.city=new RegExp(String(req.query.city).replace(/[.*+?^${}()|[\\]\\]/g,'\\$&'),'i');if(req.query.skill)filter.skills={$in:[new RegExp(String(req.query.skill),'i')]};const users=await User.find(filter).select('-passwordHash').limit(100).sort({createdAt:-1});res.json({providers:users.map(safeUser)});}catch(e){next(e);}});
app.get('/api/providers/:id',async(req,res,next)=>{try{const u=await User.findById(req.params.id);if(!u)return res.status(404).json({error:'Provider not found'});const reviews=await Review.find({target:u._id}).populate('author','name').sort({createdAt:-1});res.json({provider:safeUser(u),reviews});}catch(e){next(e);}});
app.get('/api/jobs',async(req,res,next)=>{try{const filter={status:'open'};if(req.query.category)filter.category=new RegExp(String(req.query.category),'i');if(req.query.city)filter.location=new RegExp(String(req.query.city),'i');if(req.query.q)filter.$or=[{title:new RegExp(String(req.query.q),'i')},{description:new RegExp(String(req.query.q),'i')}];const jobs=await Job.find(filter).populate('owner','name city').sort({createdAt:-1}).limit(100);res.json({jobs});}catch(e){next(e);}});
app.post('/api/jobs',auth,async(req,res,next)=>{try{const {title,description,category,location,budget,schedule}=req.body;if(!title||!description||!category||!location)return res.status(400).json({error:'Title, description, category and location are required'});const job=await Job.create({title,description,category,location,budget,schedule,owner:req.user.id});res.status(201).json({job});}catch(e){next(e);}});
app.get('/api/jobs/:id',async(req,res,next)=>{try{const job=await Job.findById(req.params.id).populate('owner','name city');if(!job)return res.status(404).json({error:'Job not found'});res.json({job});}catch(e){next(e);}});
app.post('/api/jobs/:id/request',auth,async(req,res,next)=>{try{const job=await Job.findById(req.params.id);if(!job)return res.status(404).json({error:'Job not found'});if(String(job.owner)===req.user.id)return res.status(400).json({error:'You cannot request your own job'});if(job.status!=='open')return res.status(400).json({error:'This job is no longer open'});const request=await WorkRequest.create({job:job._id,provider:req.user.id,customer:job.owner,note:req.body.note||''});res.status(201).json({request,message:'Request sent'});}catch(e){if(e.code===11000)return res.status(409).json({error:'You already sent a request for this job'});next(e);}});
app.get('/api/requests/mine',auth,async(req,res,next)=>{try{const requests=await WorkRequest.find({$or:[{provider:req.user.id},{customer:req.user.id}]}).populate({path:'job',populate:{path:'owner',select:'name city'}}).populate('provider','name city skills').populate('customer','name city').sort({createdAt:-1});res.json({requests});}catch(e){next(e);}});
app.patch('/api/requests/:id',auth,async(req,res,next)=>{try{const r=await WorkRequest.findById(req.params.id);if(!r)return res.status(404).json({error:'Request not found'});if(String(r.customer)!==req.user.id)return res.status(403).json({error:'Only job owner can update this request'});if(!['accepted','declined','completed','cancelled'].includes(req.body.status))return res.status(400).json({error:'Invalid status'});r.status=req.body.status;await r.save();if(r.status==='accepted')await Job.findByIdAndUpdate(r.job,{status:'assigned'});if(r.status==='completed')await Job.findByIdAndUpdate(r.job,{status:'completed'});res.json({request:r});}catch(e){next(e);}});
app.post('/api/favorites/:id',auth,async(req,res,next)=>{try{const id=req.params.id;const u=await User.findById(req.user.id);if(u.favorites.some(x=>String(x)===id))u.favorites=u.favorites.filter(x=>String(x)!==id);else u.favorites.push(id);await u.save();res.json({favorites:u.favorites});}catch(e){next(e);}});
app.get('/api/favorites',auth,async(req,res,next)=>{try{const u=await User.findById(req.user.id).populate('favorites','name city role skills bio hourlyRate');res.json({favorites:u.favorites});}catch(e){next(e);}});
app.post('/api/reviews',auth,async(req,res,next)=>{try{const {target,rating,text,job}=req.body;if(!target||!rating)return res.status(400).json({error:'Target and rating required'});if(String(target)===req.user.id)return res.status(400).json({error:'Cannot review yourself'});const review=await Review.create({target,author:req.user.id,rating,text,job});res.status(201).json({review});}catch(e){next(e);}});
app.post('/api/reports',auth,async(req,res,next)=>{try{const {subjectType,subjectId,details}=req.body;if(!details)return res.status(400).json({error:'Please describe the issue'});const report=await Report.create({reporter:req.user.id,subjectType,subjectId,details});res.status(201).json({report,message:'Report received'});}catch(e){next(e);}});
app.get('/api/stats',async(req,res,next)=>{try{const [jobs,providers,done,users]=await Promise.all([Job.countDocuments({status:'open'}),User.countDocuments({role:{$in:['provider','both']}}),Job.countDocuments({status:'completed'}),User.countDocuments()]);res.json({jobs,providers,done,users});}catch(e){next(e);}});
app.use('/api', (req,res)=>res.status(404).json({error:'API endpoint not found'}));
app.use(errorHandler);
mongoose.connect(MONGO).then(()=>{app.listen(PORT,()=>console.log(`Smart Work Network running on http://localhost:${PORT}`));}).catch(e=>{console.error('MongoDB connection failed:',e.message);process.exit(1);});
